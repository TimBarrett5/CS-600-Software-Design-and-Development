package com.snhu.mscs.cs600.aboutfeature.ui;

// Tim Barrett 11.08.26

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

public class SunriseSunsetServiceTest {
    private static final double LAT = 38.88941;
    private static final double LNG = -77.05013;

    private MockRestServiceServer server;
    private SunriseSunsetService service;

    @BeforeEach
    void setUp() {
        RestTemplate rt = new RestTemplate();
        server = MockRestServiceServer.createServer(rt);
        service = new SunriseSunsetService(rt);
    }

    @Test
    void returnsSunriseAndSunsetOnSuccess() {
        server.expect(requestTo(Matchers.containsString("lat=38.88941"))).andRespond(withSuccess(
            "{\"results\":{\"sunrise\":\"6:42:05 AM\",\"sunset\":\"5:01:15 PM\"},\"status\":\"OK\"}",
            MediaType.APPLICATION_JSON));

        assertArrayEquals(new String[] {"Sunrise: 6:42:05 AM", "Sunset: 5:01:15 PM"}, service.getSunriseAndSet(LAT, LNG));
        server.verify();
    }

    @Test
    void handlesServerError() {
        server.expect(requestTo(Matchers.containsString("sunrisesunset.io"))).andRespond(withServerError());

        String[] out = service.getSunriseAndSet(LAT, LNG);
        assertTrue(out[0].contains("Could not reach"));
    }

    @Test
    void liveApiReturnsSunriseAndSunset() {
        SunriseSunsetService live = new SunriseSunsetService();
        String[] out = live.getSunriseAndSet(LAT, LNG);

        assertEquals(2, out.length);
        assertTrue(out[0].startsWith("Sunrise: "));
        assertTrue(out[1].startsWith("Sunset: "));
    }
    
}
