package com.snhu.mscs.cs600.aboutfeature.ui;

import java.util.Map;

import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

// Tim Barrett 11.08.26

public class SunriseSunsetService {
    private final RestTemplate restTemplate;
    
    public SunriseSunsetService() {
        this(new RestTemplate());
    }

    // Default constructor with RestTemplate to call to external API
    public SunriseSunsetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Calls API for given coordinates and extracts JSON responses
    public String[] getSunriseAndSet(double lat, double lng) {
        // Build request from coordinates
        String url = "https://api.sunrisesunset.io/json?lat=" + lat + "&lng=" + lng;
        try {
            // Call external API and get JSON response, handling empty responses
            String result = restTemplate.getForObject(url, String.class);
            if (result == null || result.isBlank()){
                return errorResult("Service returned an empty response.");
            }

            // Parse JSON text into map
            Map < String, Object > map = JsonParserFactory.getJsonParser().parseMap(result);

            // Chceck that request succeeded with OK in status field
            if (!"OK".equals(map.get("status"))) {
                return errorResult("Service reported a problem: " + map.get("status"));
            }
            
            // Check nested results for data
            if (!(map.get("results") instanceof Map<?, ?> results) || results.get("sunrise") == null ||results.get("sunset") == null) {
                return errorResult("Response was missing data.");
            }

            return new String[] {
                "Sunrise: " + results.get("sunrise"), "Sunset: " + results.get("sunset")
            };
        } catch (RestClientException e) {
            // Handle connection failures and timeouts
            return errorResult("Could not reach service.");
        } catch (JsonParseException e) {
            // Handle invalid JSON
            return errorResult("Could not read data.");
        }
        
    }

    private String[] errorResult(String message) {
        return new String[] {message};
    }
}
