# Tim Barrett - Project Read Me File

## Siging in
Replace `<pick_a_username>` with your desired username and `<pick_password>` with 
your chosen password. 

1. In the terminal start pqsl:
```
sudo -u postgres psql
```
2. At the psql prompt run:
```
\c SalesGuru
CREATE EXTENSION IF NOT EXISTS pgcrypto;
INSERT INTO guru_user (username, password, roles)
VALUES ('<pick_a_username>', crypt('<pick_password>', gen_salt('bf', 10)), ARRAY['USER']);
```
Sign in at https://localhost:8443/ with the newly created username and password.

## Apply Database Script
Do this once in the terminal from the project folder to add constraints and convert monetary columns to numerics types.

```
psql -h localhost -U cs600 -d SalesGuru -v ON_ERROR_STOP=1 -f src/main/resources/db/salesguru_plus_hardening.sql
```