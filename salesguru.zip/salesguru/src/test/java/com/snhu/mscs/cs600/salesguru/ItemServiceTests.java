package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.ConstraintViolationException;

@SpringBootTest
@Transactional
class ItemServiceTests {
    @Autowired private ItemService itemService;

    private Item newItem(String description, String cost, String retail) {
        Item item = new Item();
        item.setDescription(description);
        item.setCost(cost == null ? null : new BigDecimal(cost));
        item.setRetail(retail == null ? null : new BigDecimal(retail));
        return item;
    }

    @Test //Test 001: Valid item creation
    void createsValidItem() {
        Item saved = itemService.createItem(newItem("Card holder", "2.50", "9.99"));
        assertNotNull(saved.getItem_number());
    }

    @Test //Test 013: Negative cost rejection
    void rejectsNegativeCost() {
        assertThrows(ConstraintViolationException.class, () -> itemService.createItem(newItem("Card holder", "-1.00", "9.99")));
    }

    @Test //Test 013: Missing retail price rejected
    void rejectMissingRetail() {
        assertThrows(ConstraintViolationException.class, () -> itemService.createItem(newItem("Card holder", "2.50", null)));
    }
}
