package com.snhu.mscs.cs600.salesguru;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class LoginTests {
    private static final String USERNAME = "test_login_user";

    @Autowired private MockMvc mockMvc;
    @Autowired private GuruUserRepository userRepo;
    @Autowired private PasswordEncoder passwordEncoder;

    //Create throw away user & return random password
    private String createTestUser() {
        String secret = UUID.randomUUID().toString();
        GuruUser user = new GuruUser();
        user.setUsername(USERNAME);
        user.setPassword(passwordEncoder.encode(secret));
        user.setRoles(new String[] {"USER"});
        userRepo.save(user);
        return secret;
    }

    @Test //Test 005: Accept valid credentials
    void acceptValidCredentials() throws Exception {
        String secret = createTestUser();
        mockMvc.perform(get("/api/v1/companies").with(httpBasic(USERNAME, secret))).andExpect(status().isOk());
    }

    @Test //Test 012: Deny wrong password
    void wrongPasswordDenied() throws Exception {
        createTestUser();
        mockMvc.perform(get("/api/v1/companies").with(httpBasic(USERNAME, "wrong"))).andExpect(status().isUnauthorized());
    }

    @Test //Baseline Test 4: No credentials = no access
    void denyNoCredentials() throws Exception {
        mockMvc.perform(get("/api/v1/companies")).andExpect(status().isUnauthorized());
    }
}
