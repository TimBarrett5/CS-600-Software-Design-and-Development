package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@SpringBootTest
class DatabaseUserDetailsServiceTests {
    @Autowired private DatabaseUserDetailsService service;
    @Autowired private GuruUserRepository userRepo;

    @Test //Test 004: store passwords as hash
    void allStoredPasswordsAreHashed() {
        assertFalse(userRepo.findAll().isEmpty());
        userRepo.findAll().forEach(u -> assertTrue(u.getPassword().startsWith("$2")));
    }

    @Test //Test 012: Unknown users rejected
    void unkownUserIsRejected() {
        assertThrows(UsernameNotFoundException.class, () -> service.loadUserByUsername("nobody"));
    }

    @Test //FR-8: Roles loaded from DB
    void loadsUserWithRoles() {
        UserDetails details = service.loadUserByUsername("admin");
        assertTrue(details.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")));
    }
}
