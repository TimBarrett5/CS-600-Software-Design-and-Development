package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.ConstraintViolationException;

@SpringBootTest
@Transactional
class InvoiceServiceTests {
    @Autowired private InvoiceService invoiceService;
    @Autowired private ItemService itemService;
    @Autowired private CompanyRepository companyRepo;
    @Autowired private RepresentativeRepository representativeRepo;

    private Representative anyRepresentative() {
        return representativeRepo.listRepresentatives().get(0);
    }

    private Invoice invoiceFor(int customer_number, int representative_id) {
        Invoice invoice = new Invoice();
        invoice.setCustomer_number(customer_number);
        invoice.setRepresentative_id(representative_id);
        invoice.setDate_of_sale(LocalDate.now());
        return invoice;
    }

    private LineItem lineFor(int invoice_number, int item_number, int qty, String discount) {
        LineItem line = new LineItem();
        line.setInvoice_number(invoice_number);
        line.setItem_number(item_number);
        line.setQty(qty);
        line.setDiscount(new BigDecimal(discount));
        return line;
    }

    @Test //Test 002: Invoice for existing company with own rep
    void createsInvoiceForCompanyWithItsRepresentative() {
        Representative rep = anyRepresentative();
        Invoice saved = invoiceService.createInvoice(invoiceFor(rep.getCustomer_number(), rep.getRepresentative_id()));
        assertNotNull(saved.getInvoice_number());
    }

    @Test //Test 003: Invoice total equals sum of line items
    void totalEqualsSumOfLineItems() {
        Representative rep = anyRepresentative();
        Invoice invoice = invoiceService.createInvoice(invoiceFor(rep.getCustomer_number(), rep.getRepresentative_id()));

        Item draft = new Item();
        draft.setDescription("Test item");
        draft.setCost(new BigDecimal("4.00"));
        draft.setRetail(new BigDecimal("10.00"));
        Item item = itemService.createItem(draft);

        invoiceService.addLineItem(lineFor(invoice.getInvoice_number(), item.getItem_number(), 2, "0.00"));
        invoiceService.addLineItem(lineFor(invoice.getInvoice_number(), item.getItem_number(), 1, "50.00"));

        assertEquals(new BigDecimal("25.00"), invoiceService.calculateTotal(invoice.getInvoice_number()));
    }

    @Test //Test 010: Reject rep from different company
    void rejectRepresentativeFromAnotherCompany() {
        Representative rep = anyRepresentative();
        Company other = companyRepo.listCompanies().stream().filter(c -> c.getCustomer_number() != rep.getCustomer_number()).findFirst().orElseThrow();
        assertThrows(InvalidRequestException.class, () -> invoiceService.createInvoice(invoiceFor(other.getCustomer_number(), rep.getRepresentative_id())));
    }

    @Test //Test 010: Reject company that doesn't exist
    void rejectsNonexistentCompany() {
        Representative rep = anyRepresentative();
        assertThrows(InvalidRequestException.class, () -> invoiceService.createInvoice(invoiceFor(999999, rep.getRepresentative_id())));
    }

    @Test //Test 011: Reject bad quantoty or discount
    void rejectsZeroQuantityAndOutOfRangeDiscount() {
        assertThrows(ConstraintViolationException.class, () -> invoiceService.addLineItem(lineFor(1, 1, 0, "0.00")));
        assertThrows(ConstraintViolationException.class, () -> invoiceService.addLineItem(lineFor(1, 1, 1, "101.00")));
        assertThrows(ConstraintViolationException.class, () -> invoiceService.addLineItem(lineFor(1, 1, 1, "-1.00")));
    }
}
