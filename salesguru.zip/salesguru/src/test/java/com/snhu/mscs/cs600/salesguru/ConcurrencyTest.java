package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcurrencyTest {
    @Autowired private SalesGuruService service;

    @Test //Test 009 NFR-3: 5 concurrent user with no errors or timeouts
    void fiveConcurrent() throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(5);
        List<Future<Integer>> results = new ArrayList<>();
        for (int user = 0; user < 5; user++) {
            results.add(pool.submit(() -> {
                int count = 0;
                for (int i = 0; i < 20; i++) {
                    count += service.listCompanies().size();
                }
                return count;
            }));
        }
        for (Future<Integer> result : results) {
            assertTrue(result.get(30, TimeUnit.SECONDS) > 0);
        }
        pool.shutdown();
    }
}
