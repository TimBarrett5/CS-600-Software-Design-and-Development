package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

//Automated baseline checks NFR-8
@SpringBootTest
class RegressionTests {
    @Autowired private JdbcTemplate jdbc;
    @Autowired private SalesGuruService service;
    @Autowired private Environment env;

    private int duplicates(String table, String column) {
        return jdbc.queryForObject(
            "SELECT count(*) - count(DISTINCT " + column +") FROM " + table, Integer.class);
    }

    @Test //Baseline Tests 1 & 2
    void noDuplicateIds() {
        assertEquals(0, duplicates("company", "customer_number"));
        assertEquals(0, duplicates("representative", "representative_id"));
        assertEquals(0, duplicates("invoice", "invoice_number"));
        assertEquals(0, duplicates("items", "item_number"));
    }

    @Test //Baseline Test 3
    void RepsBelongToCompany() {
        Set<Integer> companies = service.listCompanies().stream().map(Company::getCustomer_number).collect(Collectors.toSet());
        for (Representative rep : service.listRepresentatives()) {
            assertTrue(companies.contains(rep.getCustomer_number()), "Representative " + rep.getRepresentative_id() + " has no company");
        }
    }

    @Test //Baseline Test 5
    void tlsConfig() {
        assertEquals("8443", env.getProperty("server.port"));
        assertNotNull(env.getProperty("server.ssl.key-store"));
    }

    @Test //Baseline Test 6
    void allRepsListed() {
        Representative first = service.listRepresentatives().get(0);
        List<Representative> forCompany = service.listRepresentativesForCompany(first.getCustomer_number());
        assertFalse(forCompany.isEmpty());
        forCompany.forEach(r -> assertEquals(first.getCustomer_number(), r.getCustomer_number()));
    }

    @Test //Baseline test 7
    void listsAllCompanies() {
        int inDatabase = jdbc.queryForObject("SELECT count(*) FROM company", Integer.class);
        assertEquals(inDatabase, service.listCompanies().size());
    }
}
