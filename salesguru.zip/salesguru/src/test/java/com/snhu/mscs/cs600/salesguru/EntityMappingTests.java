package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntityMappingTests {
    
    @Autowired private ItemRepository itemRepo;
    @Autowired private InvoiceRepository invoiceRepo;
    @Autowired private LineItemRepository lineItemRepo;

    @Test
    void itemMapsToItemsTable() {
        assertDoesNotThrow(() -> itemRepo.findAll());
    }

    @Test
    void invoiceMapsToInvoiceTable() {
        assertDoesNotThrow(() -> invoiceRepo.findAll());
    }

    @Test
    void lineItemMapsToLineItemsTable() {
        assertDoesNotThrow(() -> lineItemRepo.findAll());
    }
}
