package com.snhu.mscs.cs600.salesguru;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
class PerformanceTests {
    @Autowired private InvoiceService invoiceService;
    @Autowired private ItemService itemService;
    @Autowired private ItemRepository itemRepo;
    @Autowired private RepresentativeRepository representativeRepo;

    @Test //Test 008: NFR-2 Invoice with 100 line items laods in under 1 second
    void invoiceLineItemLoad() {
        Representative rep = representativeRepo.listRepresentatives().get(0);
        Invoice invoice = new Invoice();
        invoice.setCustomer_number(rep.getCustomer_number());
        invoice.setRepresentative_id((rep.getRepresentative_id()));
        invoice.setDate_of_sale(LocalDate.now());
        Integer number = invoiceService.createInvoice(invoice).getInvoice_number();

        Item draft = new Item();
        draft.setDescription("Load test item");
        draft.setCost(new BigDecimal("4.00"));
        draft.setRetail(new BigDecimal("10.00"));
        Integer itemNumber = itemService.createItem(draft).getItem_number();

        for (int i = 0; i < 100; i++) {
            LineItem line = new LineItem();
            line.setInvoice_number(number);
            line.setItem_number(itemNumber);
            line.setQty(1);
            line.setDiscount(new BigDecimal("0.00"));
            invoiceService.addLineItem(line);
        }

        long start = System.nanoTime();
        List<LineItem> line = invoiceService.listLineItems(number);
        line.forEach(invoiceService::lineTotal);
        BigDecimal total = invoiceService.calculateTotal(number);
        long millis = (System.nanoTime() - start) / 1_000_000;

        assertEquals(new BigDecimal("1000.00"), total);
        assertTrue(millis < 1000, "Invoice took " + millis + " ms");

        System.out.println("TEST 008: invoice with 100 line items loaded in " + millis + " ms");
    }

    @Test //Test 007 NFR-1 List 10,000 records in 2 seconds
    void itemListLoad() {
        List<Item> batch = new ArrayList<>();
        for (int i = 0; i < 10000; i++) {
            Item item = new Item();
            item.setDescription("Test item " + i);
            item.setCost(new BigDecimal("1.00"));
            item.setRetail(new BigDecimal("2.00"));
            batch.add(item);
        }
        itemRepo.saveAll(batch);

        long start = System.nanoTime();
        List<Item> all = itemService.listItems();
        long millis = (System.nanoTime() - start) / 1_000_000;

        assertTrue(all.size() >= 10000);
        assertTrue(millis < 2000, "List took " + millis + " ms");

        System.out.println("TEST 007: List of " + all.size() + " items loaded in " + millis + " ms");
    }
}
