package com.snhu.mscs.cs600.salesguru;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

/**
 * Invoice for list of purchased items
 * Supports FR-1 & FR-2
 */
@Entity
@Table(name = "invoice")
public class Invoice {
    
    //Create invoice number as PK
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer invoice_number;

    @NotNull(message = "Customer number is required")
    private Integer customer_number;

    @NotNull(message = "Representative ID is required")
    private Integer representative_id;

    @NotNull(message = "Date of sale is required")
    private LocalDate date_of_sale;

    public Invoice() {
    }

    public Integer getInvoice_number() {
        return invoice_number;
    }

    public void setInvoice_number(Integer invoice_number) {
        this.invoice_number = invoice_number;
    }

    public Integer getCustomer_number() {
        return customer_number;
    }

    public void setCustomer_number(Integer customer_number) {
        this.customer_number = customer_number;
    }

    public Integer getRepresentative_id() {
        return representative_id;
    }

    public void setRepresentative_id(Integer representative_id) {
        this.representative_id = representative_id;
    }

    public LocalDate getDate_of_sale() {
        return date_of_sale;
    }

    public void setDate_of_sale(LocalDate date_of_sale) {
        this.date_of_sale = date_of_sale;
    }
}
