package com.snhu.mscs.cs600.salesguru;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.BigDecimalField;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import jakarta.annotation.security.PermitAll;
import jakarta.validation.ConstraintViolationException;

//Invoice view shows lists of invoices, creates new ones and displays selected ones
//including line items and calculated totals
//Supports FR-1, Fr-2, FR-5, FR-6, FR-7 & FR-10
@Route(value = "invoices", layout = MainLayout.class)
@PageTitle("Invoices | Sales Guru+")
@PermitAll
public class InvoicesView extends VerticalLayout{
    private final InvoiceService invoiceService;
    private final ItemService itemService;
    private final SalesGuruService salesGuruService;

    private final Grid<Invoice> invoiceGrid = new Grid<>(Invoice.class, false);
    private final Grid<LineItem> lineGrid = new Grid<>(LineItem.class, false);

    private final VerticalLayout detail = new VerticalLayout();
    private final H3 detailTitle = new H3();
    private final Span totalLabel = new Span();
    private final ComboBox<Item> itemBox = new ComboBox<>("Item");
    private final IntegerField qtyField = new IntegerField("Quantity");
    private final BigDecimalField discountField = new BigDecimalField("Discount %");

    private Invoice selected;
    private Map<Integer, Item> itemsById = new HashMap<>();

    public InvoicesView(InvoiceService invoiceService, ItemService itemService, SalesGuruService salesGuruService) {
        this.invoiceService = invoiceService;
        this.itemService = itemService;
        this.salesGuruService = salesGuruService;

        setSizeFull();
        add(new H2("Invoices"), buildCreateForm(), buildInvoiceGrid(), buildDetail());
        refreshInvoices();
    }

    //FR-1 & FR-2 Build creation form with Co, Rep & date
    private HorizontalLayout buildCreateForm() {
        ComboBox<Company> company = new ComboBox<>("Company");
        company.setItems(salesGuruService.listCompanies());
        company.setItemLabelGenerator(Company::getName);

        ComboBox<Representative> rep = new ComboBox<>("Representative");
        rep.setItemLabelGenerator(r -> r.getFirst() + " " + r.getLast());
        rep.setEnabled(false);

        //Restrict to reps with chosen company
        company.addValueChangeListener(event -> {
            rep.clear();
            if (event.getValue() == null) {
                rep.setEnabled(false);
            } else {
                rep.setItems(salesGuruService.listRepresentativesForCompany(event.getValue().getCustomer_number()));
                rep.setEnabled(true);
            }
        });

        DatePicker date = new DatePicker("Date of Sale");
        date.setValue(LocalDate.now());

        Button create = new Button("Create Invoice", event -> {
            if (company.getValue() == null || rep.getValue() == null) {
                Notification.show("Choose a company & representative");
                return;
            }
            Invoice invoice = new Invoice();
            invoice.setCustomer_number(company.getValue().getCustomer_number());
            invoice.setRepresentative_id(rep.getValue().getRepresentative_id());
            invoice.setDate_of_sale(date.getValue());
            try {
                invoiceService.createInvoice(invoice);
                refreshInvoices();
                Notification.show("Invoice created");
            }catch (InvalidRequestException | ConstraintViolationException ex) {
                Notification.show(ex.getMessage());
            }
        });

        HorizontalLayout form = new HorizontalLayout(company, rep, date, create);
        form.setDefaultVerticalComponentAlignment(Alignment.END);
        return form;
    }

    private Grid<Invoice> buildInvoiceGrid() {
        invoiceGrid.addColumn(Invoice::getInvoice_number).setHeader("Invoice #").setSortable(true);
        invoiceGrid.addColumn(Invoice::getCustomer_number).setHeader("Customer #").setSortable(true);
        invoiceGrid.addColumn(Invoice::getRepresentative_id).setHeader("representative ID").setSortable(true);
        invoiceGrid.addColumn(Invoice::getDate_of_sale).setHeader("Date of Sale").setSortable(true);
        invoiceGrid.asSingleSelect().addValueChangeListener(event -> showDetail(event.getValue()));
        return invoiceGrid;
    }

    //FR-5, FR-6 & Fr-7 Build line items and total
    private VerticalLayout buildDetail() {
        itemBox.setItemLabelGenerator(Item::getDescription);
        qtyField.setValue(1);
        discountField.setValue(BigDecimal.ZERO);
        Button addLine = new Button("Add line item", event -> addLine());

        HorizontalLayout lineForm = new HorizontalLayout(itemBox, qtyField, discountField, addLine);
        lineForm.setDefaultVerticalComponentAlignment(Alignment.END);

        lineGrid.addColumn(l -> itemsById.get(l.getItem_number()).getDescription()).setHeader("Item");
        lineGrid.addColumn(LineItem::getQty).setHeader("Qty");
        lineGrid.addColumn(l -> l.getDiscount() + "%").setHeader("Discount %");
        lineGrid.addColumn(l -> invoiceService.lineTotal(l)).setHeader("Line Total");

        detail.setPadding(false);
        detail.add(detailTitle, lineForm, lineGrid, totalLabel);
        detail.setVisible(false);
        return detail;
    }

    private void showDetail(Invoice invoice) {
        selected = invoice;
        detail.setVisible(invoice != null);
        if (invoice != null) {
            refreshDetail();
        }
    }

    private void addLine() {
        if (selected == null || itemBox.getValue() == null) {
            Notification.show("Choose an item");
            return;
        }
        LineItem line = new LineItem();
        line.setInvoice_number(selected.getInvoice_number());
        line.setItem_number(itemBox.getValue().getItem_number());
        line.setQty(qtyField.getValue());
        line.setDiscount(discountField.getValue());
        try {
            invoiceService.addLineItem(line);
            refreshDetail();
        } catch (InvalidRequestException | ConstraintViolationException ex) {
            Notification.show(ex.getMessage());
        }
    }

    private void refreshInvoices() {
        invoiceGrid.setItems(invoiceService.listInvoices());
    }

    private void refreshDetail() {
        List<Item> items = itemService.listItems();
        itemsById = new HashMap<>();
        for (Item item : items) {
            itemsById.put(item.getItem_number(), item);
        }
        itemBox.setItems(items);

        Integer number = selected.getInvoice_number();
        lineGrid.setItems(invoiceService.listLineItems(number));
        detailTitle.setText("Invoice " + number);
        totalLabel.setText("Total " + invoiceService.calculateTotal(number));
    }
}
