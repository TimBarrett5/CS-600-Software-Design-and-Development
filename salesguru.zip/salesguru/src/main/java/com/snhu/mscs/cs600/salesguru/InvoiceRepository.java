package com.snhu.mscs.cs600.salesguru;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {
    @Query("SELECT i FROM Invoice i WHERE i.customer_number = :customerNumber")
    List<Invoice> listInvoicesForCompany(@Param("customerNumber") Integer customer_number);
}
