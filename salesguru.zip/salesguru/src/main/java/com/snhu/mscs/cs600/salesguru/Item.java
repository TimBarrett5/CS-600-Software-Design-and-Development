package com.snhu.mscs.cs600.salesguru;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Item is an item for sale
 * Supports FR-3, FR-4, NFR-6 & NFR-7
 */

 @Entity
 @Table(name = "items")
public class Item {
    //Create item number as PK
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer item_number;

    //Description max 255 chars
    @NotBlank(message = "Description is required")
    @Size(max = 255, message = "Description must be 255 cahracters or fewer")
    private String description;

    //Cost cannot be negative
    @NotNull(message = "Cost is required")
    @DecimalMin(value = "0.00", message = "Cost cannot be negative")
    @Digits(integer = 10, fraction = 2, message = "Cost must have at most two decimal places")
    @Column(precision = 12, scale = 2)
    private BigDecimal cost;

    //Retail sell price cannot be negative
    @NotNull(message = "Retail price is required")
    @DecimalMin(value = "0.00", message = "Retail price cannot be negative")
    @Digits(integer = 10, fraction = 2, message = "Retial price must have two decimals places at most")
    @Column(precision = 12, scale = 2)
    private BigDecimal retail;

    public Item() {
    }

    public Integer getItem_number() {
        return item_number;
    }

    public void setItem_number(Integer item_number) {
        this.item_number = item_number;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public BigDecimal getRetail() {
        return retail;
    }

    public void setRetail(BigDecimal retail) {
        this.retail = retail;
    }
}
