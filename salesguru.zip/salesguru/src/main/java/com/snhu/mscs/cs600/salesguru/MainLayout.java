package com.snhu.mscs.cs600.salesguru;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.spring.security.AuthenticationContext;

//Creates GUI with title, navigation panel and logout
//Supports FR-10
public class MainLayout extends AppLayout {
    public MainLayout(AuthenticationContext authContext) {
        H1 title = new H1("Sales Guru+");
        title.getStyle().set("font-size", "var(--lumo-font-size-l)").set("margin", "0");

        Button logout = new Button("Log out", event -> authContext.logout());

        SideNav nav = new SideNav();
        nav.addItem(new SideNavItem("Companies", CompaniesView.class));
        nav.addItem(new SideNavItem("Representatives", RepresentativesView.class));
        nav.addItem(new SideNavItem("Items", ItemsView.class));
        nav.addItem(new SideNavItem("Invoices", InvoicesView.class));

        addToDrawer(nav);
        addToNavbar(new DrawerToggle(), title, logout);
    }
}
