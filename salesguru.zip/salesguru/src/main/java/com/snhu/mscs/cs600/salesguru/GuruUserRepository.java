package com.snhu.mscs.cs600.salesguru;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GuruUserRepository extends JpaRepository<GuruUser, Integer> {

    Optional<GuruUser> findByUsername(String username);
    
}
