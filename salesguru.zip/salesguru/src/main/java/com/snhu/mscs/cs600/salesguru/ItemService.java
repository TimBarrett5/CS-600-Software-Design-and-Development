package com.snhu.mscs.cs600.salesguru;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.Valid;
/**
 * ItemService Creates business rules for items for sale
 * Supports FR-3, FR-4, & NFR-6
 */
@Service
@Validated
public class ItemService {
    private final ItemRepository itemRepo;

    public ItemService(ItemRepository itemRepo) {
        this.itemRepo = itemRepo;
    }

    //List all items for sale
    public List<Item> listItems() {
        return itemRepo.findAll();
    }

    //create, validate and save item. DB asigns item number
    public Item createItem(@Valid Item item) {
        item.setItem_number(null);
        return itemRepo.save(item);
    }
}
