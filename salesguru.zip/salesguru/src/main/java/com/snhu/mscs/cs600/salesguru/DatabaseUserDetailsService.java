package com.snhu.mscs.cs600.salesguru;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Looks up sign in user in guru_user table & verify credentials in database
 * SupportsFR-8
 */
@Service
public class DatabaseUserDetailsService implements UserDetailsService {
    private final GuruUserRepository userRepo;

    public DatabaseUserDetailsService(GuruUserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        GuruUser user = userRepo.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        String[] roles = user.getRoles() == null ? new String[0] : user.getRoles();
        return User.withUsername(user.getUsername()).password(user.getPassword()).roles(roles).build();
    }
}
