package com.snhu.mscs.cs600.salesguru;

/**
 * Imports to allow for the configuration of our Custom Security Adapter with
 * the Spring Security Framework.
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


import com.vaadin.flow.spring.security.VaadinAwareSecurityContextHolderStrategyConfiguration;
import com.vaadin.flow.spring.security.VaadinSecurityConfigurer;

/**
 * CustomSecurityAppConfig - 
 * 
 * Purpose:
 *      The purpose of this class is to configure the necessary parameters
 *      to enable Spring Security for our Web Application. This will allow
 *      for authentication and authorization of users to control access to
 *      our API.
 * 
 * Class Level Annotations:
 *      @Configuration - This tells the Spring Framework that this class
 *      is going to have configuration items that are pulled from other
 *      parts of the Framework.
 * 
 *      @EnableWebSecurity - This annotation enables web security features
 *      in Spring Security to allow for the implemenation of authentication
 *      and authorization of users. 
 * 
 * Sample Output: N/A
 *  
 * Constraints: N/A
 * 
 * Expected Results:
 *      The proper configuration of this class will require anyone
 *      trying to get data from an API endpoint to authenticate. However
 *      it will permit anyone to query the /version endpoint without hinderance.
 * 
 * Version              Author      Date            Description
 * ***********************************************************************
 *     1                 fjm        6-Oct-2025     Initial Creation
 */
@Configuration
@EnableWebSecurity
@Import(VaadinAwareSecurityContextHolderStrategyConfiguration.class)
public class CustomSecurityAppConfig {

    /**
     * passwordEncoder - This is a bean the provides a utility method for
     * encoding a user submitted password to match for authentication.
     * 
     * @return A BCryptPasswordEncoder object that can be used to create a
     *         cryptographic hash of a password for secure storage.
     */
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    //Baseline Req-4 existing endpoints keep HTTP Basic
    @Bean
    @Order(1)
    SecurityFilterChain apiSecurityFilterChain(HttpSecurity http) throws Exception {
        http.securityMatcher("/api/**").authorizeHttpRequests(auth -> auth.requestMatchers("/api/v1/version").permitAll()
            .anyRequest().authenticated()).httpBasic(Customizer.withDefaults());
        return http.build();
    }

    //Use login form
    @Bean
    @Order(2)
    SecurityFilterChain uiSecurityFilterChain(HttpSecurity http) throws Exception {
        return http.with(VaadinSecurityConfigurer.vaadin(), configurer -> {
            configurer.loginView(LoginView.class);
        }).build();
    }
}