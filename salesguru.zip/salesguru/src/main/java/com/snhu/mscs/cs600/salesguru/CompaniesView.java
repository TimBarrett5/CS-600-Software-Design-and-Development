package com.snhu.mscs.cs600.salesguru;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;

import jakarta.annotation.security.PermitAll;

//Create comapny view for Baseline Req-7 & FR-10
@Route(value = "companies", layout = MainLayout.class)
@RouteAlias(value = "", layout = MainLayout.class)
@PageTitle("Companies | Sales Guru+")
@PermitAll
public class CompaniesView extends VerticalLayout {
    public CompaniesView(SalesGuruService service) {
        Grid<Company> grid = new Grid<>(Company.class, false);
        grid.addColumn(Company::getCustomer_number).setHeader("Customer #").setSortable(true);
        grid.addColumn(Company::getName).setHeader("Name").setSortable(true);
        grid.addColumn(Company::getCity).setHeader("City").setSortable(true);
        grid.addColumn(Company::getState).setHeader("State").setSortable(true);
        grid.addColumn(Company::getZip).setHeader("Zip Code").setSortable(true);
        grid.setItems(service.listCompanies());

        setSizeFull();
        add(new H2("Companies"), grid);
    }
}
