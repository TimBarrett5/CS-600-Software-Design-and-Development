package com.snhu.mscs.cs600.salesguru;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.Valid;

/**
 * Business rules for invoices and line items
 * Supports FR-1, FR-2, FR-5, FR-6, & FR-7
 */
@Service
@Validated
public class InvoiceService {
    private static final BigDecimal ONE_HUNDRED = new BigDecimal("100");

    private final InvoiceRepository invoiceRepo;
    private final LineItemRepository lineItemRepo;
    private final ItemRepository itemRepo;
    private final CompanyRepository companyRepo;
    private final RepresentativeRepository representativeRepo;

    public InvoiceService(
        InvoiceRepository invoiceRepo,
        LineItemRepository lineItemRepo, 
        ItemRepository itemRepo, 
        CompanyRepository companyRepo, 
        RepresentativeRepository representativeRepo) {
        this.invoiceRepo = invoiceRepo;
        this.lineItemRepo = lineItemRepo;
        this.itemRepo = itemRepo;
        this.companyRepo = companyRepo;
        this.representativeRepo = representativeRepo;
    }

    public List<Invoice> listInvoices() {
        return invoiceRepo.findAll();
    }

    public List<Invoice> listInvoicesForCompany(Integer customer_number) {
        return invoiceRepo.listInvoicesForCompany(customer_number);
    }

    public List<LineItem> listLineItems(Integer invoice_number) {
        return lineItemRepo.listLineItemsForInvoice(invoice_number);
    }

    /**
     * Create invoice saves new invoice but company must exist and rep must work
     * for company. DB assigns invoice number
     */
    public Invoice createInvoice(@Valid Invoice invoice) {
        if (!companyRepo.existsById(invoice.getCustomer_number())) {
            throw new InvalidRequestException("Comapny " + invoice.getCustomer_number() + " does not exist");
        }

        Representative rep = representativeRepo.findById(invoice.getRepresentative_id()).orElseThrow(
            () -> new InvalidRequestException("Representative " + invoice.getRepresentative_id() + " does not exist"));

        if (rep.getCustomer_number() != invoice.getCustomer_number()) {
            throw new InvalidRequestException("Representative " + invoice.getRepresentative_id() + " does not work for company " + invoice.getCustomer_number());
        }
        
        invoice.setInvoice_number(null);
        return invoiceRepo.save(invoice);
    }

    //Add line item saves line on existing invoice for existing item. Validate qty and discount by annotation on LineItem
    public LineItem addLineItem(@Valid LineItem line) {
        if (!invoiceRepo.existsById(line.getInvoice_number())) {
            throw new InvalidRequestException("Invoice " + line.getInvoice_number() + " does not exist");
        }
        if (!itemRepo.existsById(line.getItem_number())) {
            throw new InvalidRequestException("Item " + line.getItem_number() + " does not exist");
        }
        line.setLine_item_id(null);
        return lineItemRepo.save(line);
    }
    //Line total
    public BigDecimal lineTotal(LineItem line) {
        Item item = itemRepo.findById(line.getItem_number()).orElseThrow(() -> new InvalidRequestException("Item " + line.getItem_number() + "does not exist"));
        BigDecimal percentPaid = ONE_HUNDRED.subtract(line.getDiscount());
        return item.getRetail().multiply(BigDecimal.valueOf(line.getQty())).multiply(percentPaid).divide(ONE_HUNDRED, 2, RoundingMode.HALF_UP);
    }

    //Calculation total
    public BigDecimal calculateTotal(Integer invoice_number) {
        BigDecimal total = BigDecimal.ZERO.setScale(2);
        for (LineItem line : lineItemRepo.listLineItemsForInvoice(invoice_number)) {
            total = total.add(lineTotal(line));
        }
        return total;
    }
}
