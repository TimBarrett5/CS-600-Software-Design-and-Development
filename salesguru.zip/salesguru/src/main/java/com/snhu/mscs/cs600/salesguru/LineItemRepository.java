package com.snhu.mscs.cs600.salesguru;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface LineItemRepository extends JpaRepository<LineItem, Integer>{
    @Query("SELECT l FROM LineItem l WHERE l.invoice_number = :invoiceNumber")
    List<LineItem> listLineItemsForInvoice(@Param("invoiceNumber") Integer invoice_number);
}
