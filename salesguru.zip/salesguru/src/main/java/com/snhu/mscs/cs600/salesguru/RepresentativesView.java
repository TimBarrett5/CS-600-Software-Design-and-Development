package com.snhu.mscs.cs600.salesguru;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import jakarta.annotation.security.PermitAll;

//Display all reps Baseline Req-6 & FR-10
@Route(value = "representatives", layout = MainLayout.class)
@PageTitle("Representatives | Sales Guru+")
@PermitAll
public class RepresentativesView extends VerticalLayout {
    public RepresentativesView(SalesGuruService service) {
        Grid<Representative> grid = new Grid<>(Representative.class, false);
        grid.addColumn(Representative::getRepresentative_id).setHeader("Representative ID").setSortable(true);
        grid.addColumn(Representative::getCustomer_number).setHeader("Customer #").setSortable(true);
        grid.addColumn(Representative::getFirst).setHeader("First Name").setSortable(true);
        grid.addColumn(Representative::getLast).setHeader("Last Name").setSortable(true);
        grid.addColumn(Representative::getDirect_line).setHeader("Direct Line").setSortable(false);
        grid.addColumn(Representative::getMobile).setHeader("Mobile #").setSortable(false);
        grid.setItems(service.listRepresentatives());

        setSizeFull();
        add(new H2("Representatives"), grid);
    }
}
