package com.snhu.mscs.cs600.salesguru;

/**
 * Throw invalid exception when requests break business rules
 * For example, creating an invoice for company that doesn't exist
 */
public class InvalidRequestException extends RuntimeException {
    public InvalidRequestException(String message) {
        super(message);
    }
}
