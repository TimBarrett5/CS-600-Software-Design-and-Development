package com.snhu.mscs.cs600.salesguru;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.BigDecimalField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import jakarta.annotation.security.PermitAll;

//Items view lists itmes for sale and allows user to add
//Supports FR-3, FR-4, & FR-10
@Route(value = "items", layout = MainLayout.class)
@PageTitle("Items | Sales Guru +")
@PermitAll
public class ItemsView extends VerticalLayout {
    private final ItemService itemService;
    private final Grid<Item> grid = new Grid<>(Item.class, false);
    private final BeanValidationBinder<Item> binder = new BeanValidationBinder<>(Item.class);

    public ItemsView(ItemService itemService) {
        this.itemService = itemService;

        TextField description = new TextField("Description");
        BigDecimalField cost = new BigDecimalField("Cost");
        BigDecimalField retail = new BigDecimalField("Retail Price");
        Button add = new Button("Add Item", event -> saveItem());

        binder.forField(description).bind("description");
        binder.forField(cost).bind("cost");
        binder.forField(retail).bind("retail");

        grid.addColumn(Item::getItem_number).setHeader("Item #").setSortable(true);
        grid.addColumn(Item::getDescription).setHeader("Item Description").setSortable(false);
        grid.addColumn(Item::getCost).setHeader("Cost").setSortable(true);
        grid.addColumn(Item::getRetail).setHeader("Retail Price)").setSortable(true);
        refresh();

        HorizontalLayout form = new HorizontalLayout(description, cost, retail, add);
        form.setDefaultVerticalComponentAlignment(Alignment.END);

        setSizeFull();
        add(new H2("Items"), form, grid);
    }

    //Save item validates form and saves through the service
    private void saveItem() {
        Item item = new Item();
        if (binder.writeBeanIfValid(item)) {
            itemService.createItem(item);
            binder.readBean(null);
            refresh();
            Notification.show("Item added");
        }
    }

    private void refresh() {
        grid.setItems(itemService.listItems());
    }
}
