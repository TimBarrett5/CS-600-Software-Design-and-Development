package com.snhu.mscs.cs600.salesguru;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;

/*
 * Line items show each item in a purchase
 * Supports FR-5 & FR-6
 */
@Entity
@Table(name = "line_items")
public class LineItem {

    //Create line item id as PK
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer line_item_id;

    @NotNull(message = "Invoice number is required")
    private Integer invoice_number;

    @NotNull(message = "Item number is required")
    private Integer item_number;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be greater than 0")
    private Integer qty;

    @NotNull(message = "Discount is required")
    @DecimalMin(value = "0.00", message = "Discount must be greater than or equal to 0%")
    @DecimalMax(value = "100.00", message = "Discount must not exceed 100%")
    @Column(precision = 5, scale = 2)
    private BigDecimal discount;

    public LineItem() {
    }

    public Integer getLine_item_id() {
        return line_item_id;
    }

    public void setLine_item_id(Integer line_item_id) {
        this.line_item_id = line_item_id;
    }

    public Integer getInvoice_number() {
        return invoice_number;
    }

    public void setInvoice_number(Integer invoice_number) {
        this.invoice_number = invoice_number;
    }

    public Integer getItem_number() {
        return item_number;
    }

    public void setItem_number(Integer item_number) {
        this.item_number = item_number;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }
}
