BEGIN;

--Use numeric for exact monetary values
ALTER TABLE items ALTER COLUMN cost TYPE NUMERIC(12,2) USING cost::NUMERIC(12,2);
ALTER TABLE items ALTER COLUMN retail TYPE NUMERIC(12,2) USING retail::NUMERIC(12,2);
ALTER TABLE line_items ALTER COLUMN discount TYPE NUMERIC(5,2) USING discount::NUMERIC(5,2);

--items: Require prices & disallow negatives
ALTER TABLE items ALTER COLUMN cost SET NOT NULL;
ALTER TABLE items ALTER COLUMN retail SET NOT NULL;
ALTER TABLE items ADD CONSTRAINT items_cost_nonneg CHECK (cost >= 0);
ALTER TABLE items ADD CONSTRAINT items_retail_nonneg CHECK (retail >= 0);

--line_items: Give PK, link to items, enforce rules
ALTER TABLE line_items ADD PRIMARY KEY (id);
ALTER TABLE line_items ALTER COLUMN qty SET NOT NULL;
ALTER TABLE line_items ALTER COLUMN item_number SET NOT NULL;
ALTER TABLE line_items ADD CONSTRAINT line_items_item_fk FOREIGN KEY (item_number) REFERENCES items(item_number);
ALTER TABLE line_items ADD CONSTRAINT line_items_wty_positive CHECK (qty > 0);
ALTER TABLE line_items ADD CONSTRAINT line_items_discount_range CHECK (discount BETWEEN 0 AND 100);

--VALIDATE FKs
ALTER TABLE representative VALIDATE CONSTRAINT customer_number_key;
ALTER TABLE invoice VALIDATE CONSTRAINT invoice_key;
ALTER TABLE invoice VALIDATE CONSTRAINT invoice_rep;
ALTER TABLE line_items VALIDATE CONSTRAINT line_invoice;

--Authenticate username uniqueness
ALTER TABLE guru_user ADD CONSTRAINT guru_user_name_uk UNIQUE (username);

COMMIT;