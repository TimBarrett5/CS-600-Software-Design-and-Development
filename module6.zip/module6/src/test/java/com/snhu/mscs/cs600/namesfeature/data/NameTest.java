package com.snhu.mscs.cs600.namesfeature.data;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class NameTest {
    private Name makeName(String first, String last) {
        Name n = new Name();
        n.setFirst(first);
        n.setLast(last);
        return n;
    }

    @Test
    void getEmail_baseName() {
        assertEquals("tim.barrett@example.com", makeName("Tim", "Barrett").getEmail());
    }

    @Test
    void getEmail_lowercase() {
        assertEquals("tim.barrett@example.com", makeName("TIM", "BARRETT").getEmail());
    }

    @Test
    void getEmail_trimWhitespace() {
        assertEquals("tim.barrett@example.com", makeName(" Tim ", " Barr ett ").getEmail());
    }

    @Test
    void getEmail_emptyFirst() {
        assertEquals("", makeName(" ", "Barrett").getEmail());
    }

    @Test
    void getEmail_emptyLast() {
        assertEquals("", makeName("Tim", " ").getEmail());
    }

    @Test
    void getEmail_dropCharacters() {
        assertEquals("sean.omalley@example.com", makeName("Sean", "O'Malley").getEmail());
    }

    @Test
    void getEmail_keepHyphen() {
        assertEquals("tim.barrett-kelley@example.com", makeName("Tim", "Barrett-Kelley").getEmail());
    }

    @Test
    void existingGetsTest() {
        Name n = makeName("Tim", "Barrett");
        n.setMiddle("A");
        n.setSuffix("Jr");
        assertEquals("Tim", n.getFirst());
        assertEquals("A", n.getMiddle());
        assertEquals("Barrett", n.getLast());
        assertEquals("Jr", n.getSuffix());
    }
}
